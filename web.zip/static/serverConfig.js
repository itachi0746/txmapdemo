window.config = {
  baseURL: 'http://192.168.5.88:8105/wechat/'
}
console.log('window.config',window.config)
